# Sprint

**Milestone:** D1 – Core Transaction Management

**Sprint:** D1.7 – Search & Filter

**Feature Branch:**

```text
feature/pfl-d1-7-search-filter
```

---

# Objective

Implement transaction search and filtering capabilities to allow users to quickly locate financial records while preserving the existing layered architecture and maintaining a responsive user experience.

This sprint extends the transaction retrieval capability without introducing architectural changes.

---

# Scope

## Service Layer

Implement search functionality within `TransactionService`.

Create:

```text
searchTransactions(searchCriteria)
```

Responsibilities:

- Retrieve all transactions from the repository.
- Apply business filtering.
- Support filtering by:
  - Description
  - Transaction Type
  - Category
  - Date Range
- Support combined filters.
- Return filtered domain objects.

Filtering logic belongs exclusively in the Service layer.

---

## Search Criteria Model (Recommended)

Introduce a dedicated Search Criteria model instead of passing a generic object.

Example:

```javascript
{
  description: "",
  transactionType: "",
  category: "",
  startDate: null,
  endDate: null
}
```

Purpose:

- Strong API contract
- Easier validation
- Better extensibility
- Consistent with existing domain-oriented architecture

This model should remain lightweight and immutable where practical.

---

## Repository

Reuse the existing retrieval methods.

Repository responsibilities remain:

- Persistence
- Retrieval

Repository must **not** implement business filtering.

Do not introduce repository-side optimization during this sprint.

---

## WebApp

Expose:

```text
getFilteredTransactions(searchCriteria)
```

Responsibilities:

- Receive Search Criteria
- Delegate to TransactionService
- Return filtered transactions

Business logic must not be duplicated inside WebApp.

---

## UI

Enhance the transaction page with:

- Search textbox
- Transaction Type filter
- Category filter
- Date range selector
- Clear Filters button

Filtering should update the transaction list dynamically using:

```text
google.script.run
```

without requiring a page refresh.

---

# Constraints

- Preserve the current layered architecture.
- Keep all business filtering inside TransactionService.
- Repository remains persistence-only.
- Reuse existing repository methods.
- No architectural refactoring.
- No regression to CRUD functionality.
- No regression to Dashboard functionality.
- Keep the implementation simple, maintainable, and deterministic.
- Stop and report if architectural changes become necessary.

---

# Acceptance Criteria

- Search by description works.
- Filter by transaction type works.
- Filter by category works.
- Filter by date range works.
- Multiple filters can be combined.
- Clear Filters restores the complete transaction list.
- Results are accurate.
- CRUD functionality remains unaffected.
- Dashboard functionality remains unaffected.
- Review artifacts correctly describe the D1.7 implementation.

---

# Deliverables

## Application

- `src/service/TransactionService.gs`
- Search Criteria model (if introduced)
- `src/app/WebApp.gs`
- `src/ui/Transactions.html`
- Supporting JavaScript updates
- Integration tests (where applicable)

## Engineering

Regenerate the complete Engineering Review Package:

- technical-lead-approval.md
- implementation-summary.md
- architecture-notes.md
- changed-files.md
- validation.md
- self-review.md
- checklist.md
- gemini-handover.md
- manifest.json

---

# Conventional Commit

Approval Document

```powershell
git commit -m "docs(engineering): approve D1.7 search & filter"
```

Implementation

```powershell
git commit -m "feat(search): implement transaction search and filtering"
```

---

# Stop Condition

Stop implementation immediately if:

- Repository responsibilities must expand beyond persistence and retrieval.
- Search requires architectural redesign.
- Business filtering cannot remain inside TransactionService.
- Existing CRUD functionality regresses.
- Dashboard functionality regresses.
- Acceptance Criteria cannot be achieved within the approved architecture.

Do not make architectural decisions independently.

Instead:

1. Document the issue.
2. Explain the root cause.
3. Describe available implementation options.
4. Assess the impact of each option.
5. Return control to the Technical Lead.

---

# Technical Lead Review

## Status

✅ **Approved for Implementation**

The proposed implementation plan aligns with the approved architecture and satisfies the objectives of Sprint D1.7.

The current design preserves clear separation of responsibilities:

```text
Transactions UI
        │
        ▼
WebApp
        │
        ▼
TransactionService
        │
        ▼
GoogleSheetsTransactionRepository
```

### Technical Lead Recommendations

The following recommendation is **approved for implementation** as part of this sprint:

- Introduce a lightweight `SearchCriteria` model instead of passing a generic object between the UI, WebApp, and Service layers.
- Keep the model simple and focused on representing filter parameters.
- Centralize validation and filtering logic within `TransactionService`.
- Continue treating the repository as a persistence and retrieval layer only.

This recommendation improves maintainability and extensibility without increasing unnecessary complexity.

### Parking Lot (Post-MVP)

The following is **not** part of Sprint D1.7:

- Repository-side query optimization.
- Indexed searching.
- Server-side filtering against Google Sheets.

The current in-memory filtering approach is appropriate for the expected MVP data volume and best aligns with the project's principles of simplicity, maintainability, and low operating cost.
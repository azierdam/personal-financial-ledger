# UI Architecture

## Overview
The PFL application uses a server-side rendered UI approach using Google Apps Script's `HtmlService`.

## Structure
- `src/ui/`: Contains all HTML templates and styles.
- `Index.html`: The main entry point shell, integrating partials.
- `WebAppAdapter.gs`: Handles `doGet` requests and renders the main index.

## Partials
- `Header.html`: Application header.
- `Navigation.html`: Main navigation sidebar.
- `Dashboard.html`: Placeholder for the dashboard content.
- `Styles.html`: Application-wide CSS.

## Pattern
Templates utilize the `include(filename)` helper function in `WebAppAdapter.gs` to inject partials into the main layout.

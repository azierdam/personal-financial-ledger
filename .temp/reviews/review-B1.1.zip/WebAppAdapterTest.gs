/**
 * Unit tests for WebAppAdapter.
 */
function testWebAppAdapterDoGet() {
  const output = doGet({});
  if (!output || typeof output.getTitle !== 'function') {
    throw new Error('doGet did not return a valid HtmlOutput object');
  }
  
  if (output.getTitle() !== 'Personal Financial Ledger') {
    throw new Error('Incorrect title');
  }
}
